export default function HomeStyles() {
  return (
    <style>{`
      @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;0,900;1,700&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600;9..40,700;9..40,800&display=swap');

      /* ── Design Tokens ─────────────────────────────────────────────────── */
      :root {
        --brand-ocean:   #2B96A8;
        --brand-navy:    #053366;
        --brand-cyan:    #02AFCF;
        --brand-sand:    #F7F5F2;
        --brand-gold:    #D4A84B;
        --text-primary:  #0F172A;
        --text-secondary:#475569;
        --text-muted:    #94A3B8;
        --border-light:  #E8ECF0;
        --white:         #FFFFFF;
        --radius-sm:     8px;
        --radius-md:     14px;
        --radius-lg:     20px;
        --radius-xl:     28px;
        --shadow-sm:     0 1px 3px rgba(15,23,42,0.04), 0 4px 12px rgba(15,23,42,0.04);
        --shadow-md:     0 4px 16px rgba(15,23,42,0.06), 0 12px 32px rgba(15,23,42,0.06);
        --shadow-lg:     0 8px 32px rgba(15,23,42,0.08), 0 24px 56px rgba(15,23,42,0.08);
        --shadow-ocean:  0 8px 32px rgba(43,150,168,0.20);
        --transition:    all 0.25s cubic-bezier(0.4,0,0.2,1);
      }

      /* ── Global Reset ──────────────────────────────────────────────────── */
      *, *::before, *::after { margin: 0; padding: 0; box-sizing: border-box; }
      html { scroll-behavior: smooth; }
      body {
        font-family: 'DM Sans', sans-serif;
        background: var(--white);
        color: var(--text-primary);
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
      }

      /* ── Typography ────────────────────────────────────────────────────── */
      .display-serif {
        font-family: 'Playfair Display', serif;
        font-weight: 900;
        letter-spacing: -1.5px;
        line-height: 1.08;
        color: var(--brand-navy);
      }
      .eyebrow {
        display: inline-flex;
        align-items: center;
        gap: 10px;
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 3px;
        color: var(--brand-ocean);
        text-transform: uppercase;
        margin-bottom: 16px;
      }
      .eyebrow::before {
        content: '';
        display: block;
        width: 24px;
        height: 2px;
        background: var(--brand-ocean);
        border-radius: 2px;
        flex-shrink: 0;
      }

      /* ── Slide backgrounds ─────────────────────────────────────────────── */
      .slide-bg {
        position: absolute; inset: 0;
        background-size: cover;
        background-position: center;
        transition: opacity 0.7s ease, transform 8s ease;
      }

      /* ── Section eyebrow ───────────────────────────────────────────────── */
      .section-eyebrow {
        display: inline-flex; align-items: center; gap: 10px;
        font-size: 11px; font-weight: 700; letter-spacing: 3px;
        color: var(--brand-ocean); text-transform: uppercase; margin-bottom: 16px;
      }
      .section-eyebrow::before {
        content: ''; width: 24px; height: 2px;
        background: var(--brand-ocean); border-radius: 2px; display: block;
      }

      /* ── Section title ─────────────────────────────────────────────────── */
      .section-title {
        font-family: 'Playfair Display', serif;
        font-size: clamp(30px, 4vw, 50px);
        font-weight: 900;
        color: var(--brand-navy);
        letter-spacing: -1.5px;
        line-height: 1.08;
      }
      .section-title-light { color: #FFFFFF; }

      /* ── Buttons ───────────────────────────────────────────────────────── */
      .btn-primary {
        display: inline-flex; align-items: center; gap: 9px;
        padding: 13px 26px;
        background: var(--brand-ocean);
        color: white;
        border-radius: var(--radius-md);
        font-size: 14px; font-weight: 700;
        font-family: 'DM Sans', sans-serif;
        border: 2px solid var(--brand-ocean);
        cursor: pointer; text-decoration: none;
        transition: var(--transition);
        box-shadow: var(--shadow-ocean);
        letter-spacing: 0.2px;
      }
      .btn-primary:hover {
        background: transparent;
        color: var(--brand-ocean);
        transform: translateY(-2px);
        box-shadow: 0 12px 40px rgba(43,150,168,0.25);
      }

      .btn-ghost {
        display: inline-flex; align-items: center; gap: 9px;
        padding: 13px 26px;
        background: rgba(255,255,255,0.12);
        backdrop-filter: blur(16px);
        border: 1.5px solid rgba(255,255,255,0.75);
        color: white;
        border-radius: var(--radius-md);
        font-size: 14px; font-weight: 600;
        font-family: 'DM Sans', sans-serif;
        cursor: pointer; text-decoration: none;
        transition: var(--transition);
      }
      .btn-ghost:hover {
        background: white;
        color: var(--brand-navy);
        border-color: white;
        transform: translateY(-2px);
      }

      .btn-outline {
        display: inline-flex; align-items: center; gap: 9px;
        padding: 11px 22px;
        background: white;
        border: 1.5px solid var(--border-light);
        color: var(--text-secondary);
        border-radius: var(--radius-md);
        font-size: 13px; font-weight: 600;
        font-family: 'DM Sans', sans-serif;
        cursor: pointer; text-decoration: none;
        transition: var(--transition);
      }
      .btn-outline:hover {
        border-color: var(--brand-ocean);
        color: var(--brand-ocean);
        box-shadow: var(--shadow-sm);
        transform: translateY(-1px);
      }

      .btn-link {
        display: inline-flex; align-items: center; gap: 8px;
        padding: 9px 18px;
        color: var(--brand-ocean);
        border: 1.5px solid var(--brand-ocean);
        border-radius: var(--radius-sm);
        font-size: 13px; font-weight: 700;
        text-decoration: none;
        transition: var(--transition);
        letter-spacing: 0.1px;
      }
      .btn-link:hover {
        background: var(--brand-ocean);
        color: white;
        transform: translateY(-1px);
        box-shadow: var(--shadow-ocean);
      }

      /* ── Cards ─────────────────────────────────────────────────────────── */
      .exc-card {
        border-radius: var(--radius-lg);
        overflow: hidden;
        background: white;
        border: 1px solid var(--border-light);
        transition: var(--transition);
        cursor: pointer;
        text-decoration: none;
        display: block;
        color: inherit;
        box-shadow: var(--shadow-sm);
      }
      .exc-card:hover {
        transform: translateY(-6px);
        box-shadow: var(--shadow-lg);
        border-color: rgba(43,150,168,0.2);
      }
      .exc-card img { transition: transform 0.5s cubic-bezier(0.4,0,0.2,1); display: block; }
      .exc-card:hover img { transform: scale(1.06); }

      /* ── Path cards ────────────────────────────────────────────────────── */
      .path-card {
        flex: 1; padding: 32px 28px;
        border-radius: var(--radius-xl);
        border: 1.5px solid;
        cursor: pointer;
        transition: var(--transition);
        backdrop-filter: blur(16px);
        display: flex; flex-direction: column; gap: 16px;
      }
      .path-card:hover { transform: translateY(-6px); }

      .path-card-btn {
        display: inline-flex; align-items: center; gap: 9px;
        padding: 12px 22px; border-radius: var(--radius-md);
        font-size: 13px; font-weight: 700;
        font-family: 'DM Sans', sans-serif;
        text-decoration: none; cursor: pointer; border: none;
        transition: var(--transition); margin-top: auto;
        letter-spacing: 0.1px;
      }
      .path-card-btn:hover { transform: translateY(-2px); }

      /* ── Heart btn ─────────────────────────────────────────────────────── */
      .heart-btn {
        position: absolute; top: 12px; right: 12px;
        width: 36px; height: 36px; border-radius: 50%;
        background: rgba(255,255,255,0.95);
        border: none; cursor: pointer;
        display: flex; align-items: center; justify-content: center;
        transition: var(--transition);
        box-shadow: 0 2px 10px rgba(0,0,0,0.15); z-index: 2;
      }
      .heart-btn:hover { transform: scale(1.15); box-shadow: 0 4px 20px rgba(0,0,0,0.2); }

      /* ── Presta banner ─────────────────────────────────────────────────── */
      .presta-banner {
        display: flex; align-items: center; justify-content: space-between; gap: 20px;
        padding: 22px 30px; border-radius: var(--radius-lg);
        background: rgba(255,255,255,0.07);
        border: 1px solid rgba(255,255,255,0.15);
        margin-top: 48px; cursor: pointer;
        transition: var(--transition);
      }
      .presta-banner:hover { background: rgba(255,255,255,0.12); transform: translateY(-2px); }

      /* ── Section layout ────────────────────────────────────────────────── */
      .section-pad { padding: 96px 72px; }

      /* ── Animations ────────────────────────────────────────────────────── */
      @keyframes fadeUp {
        from { opacity: 0; transform: translateY(22px); }
        to   { opacity: 1; transform: translateY(0); }
      }
      .fu { animation: fadeUp 0.65s cubic-bezier(0.16,1,0.3,1) forwards; opacity: 0; }
      .fu1 { animation-delay: 0.08s; }
      .fu2 { animation-delay: 0.18s; }
      .fu3 { animation-delay: 0.30s; }
      .fu4 { animation-delay: 0.44s; }

      @keyframes float {
        0%, 100% { transform: translateX(-50%) translateY(0); }
        50%       { transform: translateX(-50%) translateY(8px); }
      }
      @keyframes shimmer {
        0%   { background-position: 200% 0; }
        100% { background-position: -200% 0; }
      }
      @keyframes spin { to { transform: rotate(360deg); } }
      @keyframes pulse {
        0%, 100% { opacity: 1; }
        50%       { opacity: 0.6; }
      }

      .categories-container {
        animation: fadeUp 0.55s cubic-bezier(0.16,1,0.3,1) forwards;
        opacity: 0; animation-delay: 0.35s;
      }

      /* ── Grids ─────────────────────────────────────────────────────────── */
      .grid-3 {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 24px;
      }

      /* ── Responsive ────────────────────────────────────────────────────── */
      @media (max-width: 1024px) {
        .grid-3 { grid-template-columns: repeat(2, 1fr) !important; }
        .section-pad { padding: 72px 32px !important; }
      }
      @media (max-width: 900px) {
        .paths-container { flex-direction: column !important; }
        .hero-buttons { flex-direction: column !important; align-items: flex-start !important; }
        .presta-banner { flex-direction: column !important; text-align: center !important; }
      }
      @media (max-width: 640px) {
        .grid-3 { grid-template-columns: 1fr !important; }
        .section-pad { padding: 56px 20px !important; }
      }
    `}</style>
  );
}