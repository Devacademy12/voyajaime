// app/components/touriste/BlogSection.tsx
"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabaseClient";
import Link from "next/link";
import { BlogImage } from "@/app/components/touriste/BlogImage";
import { Calendar, Clock, ArrowRight } from "lucide-react";

const COLORS: Record<string, string> = {
  Destination: "#2B96A8", Aventure: "#D97706", Culture: "#053366",
  Gastronomie: "#9CA3AF", Conseils: "#4A5568", Actualités: "#053366",
};
const FALLBACK = "https://images.unsplash.com/photo-1568515387631-8b650bbcdb90?w=800&q=80";

function fmtDate(d: string) {
  return new Date(d).toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" });
}
function readTime(content: string | null) {
  if (!content) return "2 min";
  const words = content.replace(/<[^>]*>/g, "").split(/\s+/).length;
  return `${Math.max(1, Math.ceil(words / 200))} min`;
}

const CSS = `
  .bs-section {
    padding: 100px 72px;
    background: white;
    font-family: 'DM Sans', sans-serif;
  }

  .bs-inner { max-width: 1140px; margin: 0 auto; }

  /* Header */
  .bs-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-end;
    margin-bottom: 56px;
    flex-wrap: wrap;
    gap: 20px;
  }

  .bs-eyebrow {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    font-size: 11px; font-weight: 700;
    letter-spacing: 3px; color: #2B96A8;
    text-transform: uppercase; margin-bottom: 16px;
  }
  .bs-eyebrow::before {
    content: '';
    display: block;
    width: 24px; height: 2px;
    background: #2B96A8; border-radius: 2px;
  }

  .bs-h2 {
    font-family: 'Playfair Display', serif;
    font-size: clamp(28px, 4vw, 46px);
    font-weight: 900;
    color: #053366;
    letter-spacing: -1.5px;
    line-height: 1.08;
    margin: 0;
  }

  .bs-link-all {
    display: inline-flex; align-items: center; gap: 8px;
    padding: 9px 18px; font-size: 13px; font-weight: 700;
    color: #2B96A8; text-decoration: none;
    border: 1.5px solid #2B96A8; border-radius: 10px;
    transition: all 0.2s; letter-spacing: 0.1px;
  }
  .bs-link-all:hover {
    background: #2B96A8; color: white;
    transform: translateY(-1px);
    box-shadow: 0 6px 20px rgba(43,150,168,0.25);
  }

  /* Featured card */
  .bs-featured {
    display: grid;
    grid-template-columns: 1.1fr 0.9fr;
    border-radius: 20px;
    overflow: hidden;
    background: white;
    text-decoration: none;
    color: inherit;
    transition: all 0.3s cubic-bezier(0.4,0,0.2,1);
    margin-bottom: 28px;
    border: 1px solid #EAECF0;
    box-shadow: 0 2px 8px rgba(15,23,42,0.04), 0 8px 24px rgba(15,23,42,0.04);
  }
  .bs-featured:hover {
    transform: translateY(-6px);
    box-shadow: 0 16px 48px rgba(15,23,42,0.10), 0 4px 16px rgba(43,150,168,0.06);
    border-color: rgba(43,150,168,0.18);
  }
  .bs-featured:hover .bs-feat-img { transform: scale(1.04); }
  .bs-feat-img-wrap {
    overflow: hidden; position: relative;
    min-height: 380px; background: #EEF2FF;
  }
  .bs-feat-img {
    transition: transform 0.6s cubic-bezier(0.165,0.84,0.44,1);
    width: 100%; height: 100%; object-fit: cover;
    display: block; position: absolute; inset: 0;
  }

  /* Small cards */
  .bs-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 20px;
  }
  .bs-card {
    background: white; border-radius: 16px; overflow: hidden;
    border: 1px solid #EAECF0;
    display: flex; flex-direction: column;
    text-decoration: none; color: inherit;
    transition: all 0.25s cubic-bezier(0.4,0,0.2,1);
    box-shadow: 0 1px 3px rgba(15,23,42,0.04);
  }
  .bs-card:hover {
    transform: translateY(-6px);
    border-color: rgba(43,150,168,0.2);
    box-shadow: 0 12px 36px rgba(15,23,42,0.08);
  }
  .bs-card:hover .bs-card-img { transform: scale(1.07); }
  .bs-card-img-wrap {
    height: 190px; overflow: hidden;
    background: #EEF2FF; position: relative; flex-shrink: 0;
  }
  .bs-card-img {
    transition: transform 0.5s cubic-bezier(0.4,0,0.2,1);
    width: 100%; height: 100%; object-fit: cover;
    display: block; position: absolute; inset: 0;
  }

  /* Shared */
  .bs-cat {
    display: inline-flex; align-items: center;
    padding: 5px 12px; border-radius: 100px;
    font-size: 10.5px; font-weight: 800;
    letter-spacing: 0.8px; text-transform: uppercase;
    color: white; margin-bottom: 12px;
    width: fit-content; align-self: flex-start;
  }
  .bs-meta {
    display: flex; gap: 14px;
    font-size: 12px; color: #94A3B8; font-weight: 500;
  }
  .bs-meta span { display: flex; align-items: center; gap: 5px; }

  .bs-read {
    display: inline-flex; align-items: center; gap: 7px;
    font-size: 13px; font-weight: 700; color: #2B96A8;
    text-decoration: none; transition: gap 0.2s;
    margin-top: auto; letter-spacing: 0.1px;
  }
  .bs-read:hover { gap: 10px; }

  /* CTA */
  .bs-cta-wrap { margin-top: 52px; display: flex; justify-content: center; }
  .bs-cta {
    display: inline-flex; align-items: center; gap: 10px;
    padding: 13px 32px; background: #2B96A8; color: white;
    font-weight: 700; font-size: 14px; letter-spacing: 0.1px;
    text-decoration: none; border-radius: 12px;
    transition: all 0.2s; border: 2px solid #2B96A8;
    box-shadow: 0 6px 20px rgba(43,150,168,0.25);
  }
  .bs-cta:hover {
    background: transparent; color: #2B96A8;
    transform: translateY(-2px);
    box-shadow: 0 10px 30px rgba(43,150,168,0.18);
  }

  @media(max-width: 1024px) {
    .bs-section { padding: 80px 32px; }
    .bs-featured { grid-template-columns: 1fr; }
    .bs-feat-img-wrap { min-height: 280px; }
  }
  @media(max-width: 768px) { .bs-grid { grid-template-columns: 1fr 1fr; } }
  @media(max-width: 540px) {
    .bs-section { padding: 64px 20px; }
    .bs-grid { grid-template-columns: 1fr; }
  }
`;

export default function BlogSection() {
  const [featured, setFeatured] = useState<any | null>(null);
  const [posts, setPosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const supabase = createClient();
    let mounted = true;
    (async () => {
      try {
        const { data: fData } = await supabase
          .from("blog_posts")
          .select("id, slug, title, excerpt, cover_url, category, published_at, created_at, content, views")
          .eq("is_published", true)
          .eq("is_featured", true)
          .order("published_at", { ascending: false })
          .limit(1)
          .single();

        const { data: pData } = await supabase
          .from("blog_posts")
          .select("id, slug, title, excerpt, cover_url, category, published_at, created_at, content")
          .eq("is_published", true)
          .neq("id", fData?.id ?? "")
          .order("published_at", { ascending: false })
          .limit(3);

        if (!mounted) return;
        setFeatured(fData ?? null);
        setPosts(pData ?? []);
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => { mounted = false; };
  }, []);

  if (loading) return null;
  const rest = posts || [];
  if (!featured && rest.length === 0) return null;

  return (
    <>
      <style>{CSS}</style>
      <section className="bs-section">
        <div className="bs-inner">

          {/* Header */}
          <div className="bs-header">
            <div>
              <span className="bs-eyebrow">Récits de Voyage</span>
              <h2 className="bs-h2">Histoires & Inspirations</h2>
            </div>
            <Link href="/blog" className="bs-link-all">
              Voir le blog <ArrowRight size={14} />
            </Link>
          </div>

          {/* Featured */}
          {featured && (
            <Link href={`/blog/${featured.slug}`} className="bs-featured">
              <div className="bs-feat-img-wrap">
                <BlogImage
                  src={featured.cover_url || FALLBACK}
                  alt={featured.title}
                  className="bs-feat-img"
                />
                <div style={{
                  position: "absolute", inset: 0,
                  background: "linear-gradient(to top, rgba(5,51,102,0.35), transparent 55%)",
                }} />
              </div>
              <div style={{ padding: "36px 36px", display: "flex", flexDirection: "column", gap: 14 }}>
                <span className="bs-cat" style={{ background: COLORS[featured.category] || "#2B96A8" }}>
                  {featured.category}
                </span>
                <h3 style={{
                  fontFamily: "'Playfair Display', serif",
                  fontSize: "clamp(22px, 2.5vw, 32px)",
                  fontWeight: 900, color: "#053366",
                  letterSpacing: "-0.5px", lineHeight: 1.2, margin: 0,
                }}>
                  {featured.title}
                </h3>
                {featured.excerpt && (
                  <p style={{
                    fontSize: 15, color: "#475569", lineHeight: 1.7,
                    display: "-webkit-box", WebkitLineClamp: 3,
                    WebkitBoxOrient: "vertical", overflow: "hidden", margin: 0,
                  }}>
                    {featured.excerpt}
                  </p>
                )}
                <div className="bs-meta">
                  <span><Calendar size={13} />{fmtDate(featured.published_at || featured.created_at)}</span>
                  <span><Clock size={13} />{readTime(featured.content)}</span>
                </div>
                <span className="bs-read">Lire l&apos;article <ArrowRight size={15} /></span>
              </div>
            </Link>
          )}

          {/* Grid */}
          {rest.length > 0 && (
            <div className="bs-grid">
              {rest.map((post) => {
                const catColor = COLORS[post.category] || "#2B96A8";
                return (
                  <Link key={post.id} href={`/blog/${post.slug}`} className="bs-card">
                    <div className="bs-card-img-wrap">
                      <BlogImage
                        src={post.cover_url || FALLBACK}
                        alt={post.title}
                        className="bs-card-img"
                      />
                      <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to top, rgba(15,23,42,0.4), transparent 60%)" }} />
                      <div style={{ position: "absolute", bottom: 12, left: 12 }}>
                        <span className="bs-cat" style={{ background: catColor, margin: 0 }}>
                          {post.category}
                        </span>
                      </div>
                    </div>
                    <div style={{ padding: "20px 20px 24px", display: "flex", flexDirection: "column", gap: 10, flex: 1 }}>
                      <h4 style={{
                        fontSize: 15.5, fontWeight: 700, color: "#0F172A",
                        lineHeight: 1.4, margin: 0,
                        display: "-webkit-box", WebkitLineClamp: 2,
                        WebkitBoxOrient: "vertical", overflow: "hidden",
                      }}>
                        {post.title}
                      </h4>
                      <div className="bs-meta" style={{ marginTop: "auto", paddingTop: 4 }}>
                        <span><Calendar size={11} />{fmtDate(post.published_at || post.created_at)}</span>
                      </div>
                      <span className="bs-read" style={{ fontSize: 12.5 }}>
                        Lire la suite <ArrowRight size={13} />
                      </span>
                    </div>
                  </Link>
                );
              })}
            </div>
          )}

          {/* CTA */}
          <div className="bs-cta-wrap">
            <Link href="/blog" className="bs-cta">
              Voir tous les articles <ArrowRight size={14} />
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}