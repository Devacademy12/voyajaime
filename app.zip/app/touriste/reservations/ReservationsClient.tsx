"use client";

import { useState, useCallback, useEffect, useRef } from "react";
import { createClient } from "@/lib/supabaseClient";
import Link from "next/link";
import {
  CalendarDays, MapPin, Clock, Users, Sparkles,
  CheckCircle, CreditCard, Wallet, Building2,
  ChevronRight, ChevronLeft, MessageSquare, X, Loader2,
  ShieldCheck, ArrowRight, Ticket, Phone, Navigation,
  AlertCircle, ExternalLink, Timer, History, RefreshCcw,
  Star, TrendingUp, Compass,
} from "lucide-react";

// ─── Types ───────────────────────────────────────────────────────────
interface Excursion {
  id: string;
  title: string;
  city: string;
  photos: string[];
  duration_hours: number;
  price_per_person: number;
  meeting_point?: string;
  rating?: number;
}

interface Reservation {
  id: string;
  booking_code: string;
  date: string;
  time: string;
  people_count: number;
  total_price: number;
  platform_fee: number;
  status: string;
  payment_status?: string | null;
  payment_deadline?: string | null;
  excursion_id?: string;
  excursion: Excursion | null;
}

// ─── Constantes ───────────────────────────────────────────────────────
const STATUS_CONFIG: Record<string, {
  label: string; color: string; bg: string; border: string; dot: string; glow: string;
}> = {
  pending:   { label: "En attente",  color: "#92400E", bg: "#FFFBEB", border: "#FDE68A", dot: "#F59E0B", glow: "rgba(245,158,11,.15)" },
  confirmed: { label: "Confirmée",   color: "#065F46", bg: "#ECFDF5", border: "#A7F3D0", dot: "#10B981", glow: "rgba(16,185,129,.15)" },
  completed: { label: "Terminée",    color: "#1E40AF", bg: "#EFF6FF", border: "#BFDBFE", dot: "#3B82F6", glow: "rgba(59,130,246,.15)" },
  cancelled: { label: "Annulée",     color: "#991B1B", bg: "#FFF1F2", border: "#FECDD3", dot: "#EF4444", glow: "rgba(239,68,68,.15)"  },
};

type PayMethod = "flouci" | "cash" | "bank";
const PAY_METHODS: { id: PayMethod; label: string; sub: string; Icon: React.ElementType }[] = [
  { id: "flouci", label: "Paiement en ligne",  sub: "Carte bancaire · CIB · Flouci", Icon: CreditCard },
  { id: "cash",   label: "Espèces sur place",  sub: "Paiement à la rencontre",       Icon: Wallet     },
  { id: "bank",   label: "Virement bancaire",  sub: "RIB transmis par email",        Icon: Building2  },
];
const STEPS = ["Revue", "Informations", "Paiement"];

const TODAY = new Date().toISOString().split("T")[0];

// ─── Helpers ──────────────────────────────────────────────────────────
function fmtDate(d: string, short = false) {
  if (!d) return "";
  const dt = new Date(d + "T00:00:00");
  if (short) return dt.toLocaleDateString("fr-FR", { day: "numeric", month: "short" });
  return dt.toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
}

function daysUntil(dateStr: string): number {
  const excDate = new Date(dateStr + "T00:00:00");
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  return Math.ceil((excDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
}

// ─── CSS global ───────────────────────────────────────────────────────
const GLOBAL_CSS = `
  @import url('https://fonts.googleapis.com/css2?family=Syne:wght@600;700;800&family=DM+Sans:wght@400;500;600;700&display=swap');

  @keyframes rspin   { to { transform: rotate(360deg) } }
  @keyframes fadeUp  { from { opacity:0; transform:translateY(14px) } to { opacity:1; transform:none } }
  @keyframes pulse   { 0%,100% { opacity:1 } 50% { opacity:.4 } }
  @keyframes shimmer { from { background-position: -200% 0 } to { background-position: 200% 0 } }
  @keyframes glow    { 0%,100% { box-shadow: 0 0 0 0 rgba(43,150,168,0) } 50% { box-shadow: 0 0 0 8px rgba(43,150,168,.12) } }

  * { box-sizing: border-box; }

  .res-page {
    font-family: 'DM Sans', system-ui, sans-serif;
    background: #F8FAFC;
    min-height: 100vh;
    padding: 32px 48px 60px;
    max-width: 1400px;
    margin: 0 auto;
  }

  /* ── Header ── */
  .res-header {
    display: flex;
    align-items: flex-end;
    justify-content: space-between;
    margin-bottom: 36px;
    flex-wrap: wrap;
    gap: 16px;
  }
  .res-title {
    font-family: 'Syne', sans-serif;
    font-size: 32px;
    font-weight: 800;
    color: #0A1628;
    letter-spacing: -1px;
    margin: 0 0 6px;
    line-height: 1.1;
  }
  .res-subtitle {
    font-size: 14px;
    color: #94A3B8;
    font-weight: 500;
    margin: 0;
  }

  /* ── Stats bar ── */
  .res-stats {
    display: flex;
    gap: 12px;
    margin-bottom: 28px;
    flex-wrap: wrap;
  }
  .res-stat-pill {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 18px;
    background: white;
    border: 1px solid #E2E8F0;
    border-radius: 40px;
    font-size: 13px;
    font-weight: 600;
    color: #475569;
    box-shadow: 0 1px 3px rgba(0,0,0,.04);
  }
  .res-stat-pill .num {
    font-family: 'Syne', sans-serif;
    font-size: 16px;
    font-weight: 800;
  }

  /* ── Grid ── */
  .res-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 16px;
  }
  @media (max-width: 640px) {
    .res-grid { grid-template-columns: 1fr; }
  }

  /* ── Card ── */
  .res-card {
    background: white;
    border-radius: 24px;
    border: 1px solid #E2E8F0;
    overflow: hidden;
    animation: fadeUp .35s ease both;
    transition: transform .22s cubic-bezier(.34,1.56,.64,1), box-shadow .22s ease;
    box-shadow: 0 2px 8px rgba(0,0,0,.05);
  }
  .res-card:hover {
    transform: translateY(-4px) scale(1.005);
    box-shadow: 0 16px 48px rgba(0,0,0,.1), 0 4px 16px rgba(43,150,168,.08);
  }

  /* ── Card image ── */
  .res-card-img {
    position: relative;
    height: 160px;
    overflow: hidden;
    background: linear-gradient(135deg,#0e7490,#2B96A8);
  }
  .res-card-img img {
    width: 100%; height: 100%;
    object-fit: cover;
    display: block;
    transition: transform .4s ease;
  }
  .res-card:hover .res-card-img img {
    transform: scale(1.04);
  }
  .res-card-img-overlay {
    position: absolute;
    inset: 0;
    background: linear-gradient(160deg, rgba(0,0,0,.02) 0%, rgba(0,0,0,.55) 100%);
  }

  /* ── Card body ── */
  .res-card-body {
    padding: 20px 22px 16px;
  }
  .res-card-title {
    font-family: 'Syne', sans-serif;
    font-size: 16px;
    font-weight: 700;
    color: #0A1628;
    margin: 0 0 6px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .res-card-city {
    display: flex;
    align-items: center;
    gap: 4px;
    font-size: 12px;
    color: #64748B;
    margin: 0 0 16px;
  }

  /* ── Info grid ── */
  .res-info-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 8px;
    margin-bottom: 16px;
  }
  .res-info-item {
    background: #F8FAFC;
    border: 1px solid #F1F5F9;
    border-radius: 12px;
    padding: 10px 12px;
  }
  .res-info-label {
    font-size: 10px;
    font-weight: 700;
    color: #94A3B8;
    text-transform: uppercase;
    letter-spacing: .6px;
    margin-bottom: 4px;
  }
  .res-info-value {
    font-size: 13px;
    font-weight: 700;
    color: #1E293B;
  }

  /* ── Countdown ── */
  .res-countdown {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 9px 14px;
    border-radius: 12px;
    margin-bottom: 14px;
    transition: all .3s;
  }
  .res-countdown-normal { background: #F0FDF9; border: 1.5px solid #A7F3D0; }
  .res-countdown-urgent { background: #FFF1F2; border: 1.5px solid #FECDD3; animation: pulse .9s ease infinite; }

  /* ── Footer ── */
  .res-card-footer {
    border-top: 1px solid #F1F5F9;
    padding: 14px 22px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
  }
  .res-price {
    display: flex;
    flex-direction: column;
  }
  .res-price-num {
    font-family: 'Syne', sans-serif;
    font-size: 22px;
    font-weight: 800;
    color: #0A1628;
    line-height: 1;
  }
  .res-price-label {
    font-size: 10px;
    color: #94A3B8;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: .5px;
  }

  /* ── Pay button ── */
  .res-pay-btn {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    padding: 11px 20px;
    background: linear-gradient(135deg,#0e7490,#2B96A8);
    color: white;
    border: none;
    border-radius: 14px;
    font-size: 13px;
    font-weight: 700;
    cursor: pointer;
    font-family: 'DM Sans', inherit;
    transition: all .2s;
    box-shadow: 0 4px 14px rgba(43,150,168,.35);
    animation: glow 2s ease infinite;
  }
  .res-pay-btn:hover {
    transform: translateY(-1px);
    box-shadow: 0 8px 24px rgba(43,150,168,.45);
  }

  /* ── Days badge ── */
  .res-days-badge {
    position: absolute;
    bottom: 12px;
    right: 12px;
    background: rgba(255,255,255,.95);
    backdrop-filter: blur(8px);
    border-radius: 12px;
    padding: 6px 10px;
    font-size: 11px;
    font-weight: 800;
    color: #0A1628;
    display: flex;
    align-items: center;
    gap: 4px;
    border: 1px solid rgba(255,255,255,.6);
    box-shadow: 0 2px 8px rgba(0,0,0,.12);
  }

  /* ── Status badge ── */
  .res-status-badge {
    position: absolute;
    top: 12px;
    left: 12px;
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 5px 12px;
    border-radius: 99px;
    font-size: 11px;
    font-weight: 700;
    backdrop-filter: blur(6px);
  }

  /* ── Paid badge ── */
  .res-paid-badge {
    position: absolute;
    top: 12px;
    right: 12px;
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 5px 10px;
    background: rgba(16,185,129,.9);
    border-radius: 99px;
    font-size: 10px;
    font-weight: 700;
    color: white;
    backdrop-filter: blur(6px);
  }

  /* ── Code booking ── */
  .res-code {
    font-family: 'Courier New', monospace;
    font-size: 11px;
    color: #94A3B8;
    background: #F8FAFC;
    padding: 3px 8px;
    border-radius: 6px;
    border: 1px solid #E2E8F0;
    letter-spacing: .5px;
  }

  /* ── Empty state ── */
  .res-empty {
    text-align: center;
    padding: 100px 24px;
    background: white;
    border-radius: 28px;
    border: 1px solid #E2E8F0;
  }
  .res-empty-icon {
    width: 80px; height: 80px;
    border-radius: 24px;
    background: linear-gradient(135deg,#EFF9FB,#D1FAE5);
    display: flex; align-items: center; justify-content: center;
    margin: 0 auto 24px;
    border: 1px solid #A7F3D0;
  }

  /* ── Refresh indicator ── */
  .res-refreshing {
    position: fixed;
    bottom: 24px;
    right: 24px;
    background: #0A1628;
    color: white;
    padding: 10px 18px;
    border-radius: 40px;
    font-size: 12px;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 8px;
    z-index: 1000;
    box-shadow: 0 4px 20px rgba(0,0,0,.25);
    animation: fadeUp .2s ease;
  }

  /* ── Modal ── */
  .pay-method:hover { border-color: #2B96A8 !important; background: #F0FDF9 !important; }
  .pay-btn-primary  { background: linear-gradient(135deg,#0e7490,#2B96A8); color: white; }
  .pay-btn-primary:hover { filter: brightness(1.08); box-shadow: 0 8px 24px rgba(43,150,168,.4); }
  .pay-btn-dark     { background: #0A1628; color: white; }
  .pay-btn-dark:hover { background: #1E293B; }
  .timer-urgent     { animation: pulse .8s ease-in-out infinite; }
`;

// ═══════════════════════════════════════════════════════════════════════
//  CheckoutModal (inchangé fonctionnellement, redesigné)
// ═══════════════════════════════════════════════════════════════════════
function CheckoutModal({
  reservation, onClose, onPaid, autoStart = false,
}: {
  reservation: Reservation;
  onClose: () => void;
  onPaid: (id: string) => void;
  autoStart?: boolean;
}) {
  const supabase = createClient();
  const exc      = reservation.excursion;

  const [step,        setStep]      = useState<1|2|3|4>(autoStart ? 3 : 1);
  const [specialNote, setSpecialNote] = useState("");
  const [payMethod,   setPayMethod]   = useState<PayMethod>("flouci");
  const [loading,     setLoading]     = useState(false);
  const [error,       setError]       = useState("");
  const [flouciUrl,   setFlouciUrl]   = useState<string|null>(null);
  const [cancelled,   setCancelled]   = useState(false);

  function getSecondsLeft() {
    if (!reservation.payment_deadline) return 3600;
    return Math.max(0, Math.floor((new Date(reservation.payment_deadline).getTime() - Date.now()) / 1000));
  }

  const [timeLeft, setTimeLeft] = useState<number>(getSecondsLeft);
  const timerRef = useRef<ReturnType<typeof setInterval>|null>(null);

  useEffect(() => {
    if (step === 4 || cancelled) return;
    const remaining = getSecondsLeft();
    if (remaining <= 0) { triggerCancel(); return; }
    setTimeLeft(remaining);
    timerRef.current = setInterval(() => {
      const left = getSecondsLeft();
      setTimeLeft(left);
      if (left <= 0) { clearInterval(timerRef.current!); triggerCancel(); }
    }, 1000);
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [step, cancelled]);

  async function triggerCancel() {
    setCancelled(true);
    try {
      await supabase.rpc('restore_slots_on_cancel', { p_reservation_id: reservation.id });
      await supabase.from("reservations")
        .update({ status: "cancelled", payment_status: "expired" })
        .eq("id", reservation.id).eq("status", "pending");
    } catch (e) { console.warn("Auto-cancel:", e); }
  }

  function fmtCountdown(secs: number) {
    const m = Math.floor(secs/60).toString().padStart(2,"0");
    const s = (secs%60).toString().padStart(2,"0");
    return `${m}:${s}`;
  }

  const isUrgent = timeLeft <= 300;
  const base  = reservation.total_price - reservation.platform_fee;
  const fee   = reservation.platform_fee;
  const total = reservation.total_price;

  async function addToHistory(paymentMethod: PayMethod) {
    try {
      const { data: res, error } = await supabase
        .from("reservations")
        .select("id, booking_code, date, time, people_count, total_price, platform_fee, payment_method, status, excursion_id, excursions:excursions!reservations_excursion_id_fkey(id, title, city)")
        .eq("id", reservation.id).single();
      if (error || !res) return;
      let excursionData: { id: string; title: string; city: string } | null = null;
      if (res.excursions) {
        excursionData = Array.isArray(res.excursions) ? res.excursions[0] : res.excursions;
      }
      await supabase.from("historique_reservations").insert({
        original_reservation_id: res.id,
        booking_code: res.booking_code,
        excursion_id: excursionData?.id || null,
        excursion_title: excursionData?.title || null,
        excursion_city: excursionData?.city || null,
        date: res.date, time: res.time,
        people_count: res.people_count,
        total_price: res.total_price,
        platform_fee: res.platform_fee,
        payment_method: paymentMethod,
        payment_status: "paid",
        payment_date: new Date().toISOString(),
      });
    } catch (e) { console.warn("addToHistory:", e); }
  }

  async function notifyN8n(method: PayMethod) {
    const { data: { user } } = await supabase.auth.getUser();
    fetch("/api/n8n-trigger", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        event: "payment_confirmed",
        touriste_name: user?.user_metadata?.full_name || user?.email || "Touriste",
        touriste_email: user?.email || "",
        excursion_title: exc?.title || "Excursion",
        excursion_city: exc?.city || "",
        booking_code: reservation.booking_code,
        date: reservation.date,
        people_count: reservation.people_count,
        total_price: total,
        payment_method: method,
        special_notes: specialNote || "",
      }),
    }).catch(err => console.warn("[n8n]:", err));
  }

  async function handleFlouci() {
    setLoading(true); setError("");
    try {
      const res = await fetch("/api/paiement/flouci", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reservation_id: reservation.id, special_notes: specialNote }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Erreur Flouci");
      if (specialNote) await supabase.from("reservations").update({ special_notes: specialNote }).eq("id", reservation.id);
      setFlouciUrl(data.payment_url);
    } catch (e) { setError(e instanceof Error ? e.message : "Erreur paiement."); }
    finally { setLoading(false); }
  }

  async function handleLocalPay() {
    setLoading(true); setError("");
    try {
      const { error: e1 } = await supabase.from("reservations").update({
        payment_status: "paid", payment_method: payMethod,
        special_notes: specialNote || null,
        status: "confirmed", paid_at: new Date().toISOString(),
      }).eq("id", reservation.id);
      if (e1) throw e1;
      await addToHistory(payMethod);
      await notifyN8n(payMethod);
      if (timerRef.current) clearInterval(timerRef.current);
      setStep(4); onPaid(reservation.id);
    } catch (e) { setError(e instanceof Error ? e.message : "Erreur confirmation."); }
    finally { setLoading(false); }
  }

  async function handlePay() {
    if (payMethod === "flouci") await handleFlouci();
    else await handleLocalPay();
  }

  return (
    <div style={{ position:"fixed", inset:0, background:"rgba(10,22,40,.75)", backdropFilter:"blur(10px)", zIndex:2000, display:"flex", alignItems:"center", justifyContent:"center", padding:16 }}
      onClick={e => { if (e.target === e.currentTarget && step !== 4) onClose(); }}>
      <div style={{ background:"white", borderRadius:28, width:"100%", maxWidth:520, maxHeight:"94vh", overflowY:"hidden", boxShadow:"0 40px 100px rgba(0,0,0,.35)", display:"flex", flexDirection:"column" }}>

        {/* Header sticky */}
        <div style={{ position:"sticky", top:0, background:"white", zIndex:10, borderBottom:"1px solid #F1F5F9", padding:"22px 26px 18px", flexShrink:0 }}>
          <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom: step !== 4 && !cancelled ? 18 : 0 }}>
            <div style={{ display:"flex", alignItems:"center", gap:10 }}>
              {step > 1 && step < 4 && !cancelled && (
                <button onClick={() => { setError(""); setFlouciUrl(null); setStep(s => (s-1) as 1|2|3|4); }}
                  style={{ width:34, height:34, borderRadius:"50%", border:"1.5px solid #E2E8F0", background:"white", cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center" }}>
                  <ChevronLeft size={16} color="#374151"/>
                </button>
              )}
              <div>
                {step !== 4 && !cancelled && (
                  <p style={{ fontSize:10, fontWeight:700, color:"#94A3B8", textTransform:"uppercase", letterSpacing:1.2, marginBottom:3, fontFamily:"'DM Sans',sans-serif" }}>
                    Étape {step} / 3
                  </p>
                )}
                <h2 style={{ fontSize:19, fontWeight:800, color:"#0A1628", lineHeight:1.2, fontFamily:"'Syne',sans-serif", margin:0 }}>
                  {cancelled            && "⏱ Réservation expirée"}
                  {!cancelled && step===1 && "Revue de la réservation"}
                  {!cancelled && step===2 && "Informations voyageur"}
                  {!cancelled && step===3 && "Choisir le paiement"}
                  {!cancelled && step===4 && "✓ Paiement confirmé !"}
                </h2>
              </div>
            </div>
            {step !== 4 && (
              <button onClick={onClose} style={{ width:34, height:34, borderRadius:"50%", border:"1.5px solid #E2E8F0", background:"white", cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center" }}>
                <X size={15} color="#374151"/>
              </button>
            )}
          </div>

          {step !== 4 && !cancelled && (<>
            {/* Progress */}
            <div style={{ display:"flex", gap:6, marginBottom:14 }}>
              {STEPS.map((s,i) => (
                <div key={s} style={{ flex:1 }}>
                  <div style={{ height:3, borderRadius:99, background: i < step ? "linear-gradient(90deg,#0e7490,#2B96A8)" : "#E2E8F0", transition:"background .3s", marginBottom:5 }}/>
                  <span style={{ fontSize:10, fontWeight:600, color: i < step ? "#2B96A8" : i===step-1 ? "#0A1628" : "#94A3B8", display:"block", textAlign:"center" }}>{s}</span>
                </div>
              ))}
            </div>

            {/* Timer */}
            <div className={`res-countdown ${isUrgent ? "res-countdown-urgent" : "res-countdown-normal"}`}>
              <div style={{ display:"flex", alignItems:"center", gap:6 }}>
                <Timer size={13} color={isUrgent ? "#EF4444" : "#059669"}/>
                <span style={{ fontSize:12, fontWeight:600, color: isUrgent ? "#DC2626" : "#059669" }}>
                  {isUrgent ? "⚠ Payez vite !" : "Temps restant pour payer"}
                </span>
              </div>
              <span style={{ fontFamily:"monospace", fontSize:16, fontWeight:900, color: isUrgent ? "#DC2626" : "#065F46", background: isUrgent ? "#FEE2E2" : "#D1FAE5", padding:"3px 12px", borderRadius:10 }}>
                {fmtCountdown(timeLeft)}
              </span>
            </div>

            <div style={{ padding:"10px 14px", background:"#FFFBEB", borderLeft:"3px solid #F59E0B", borderRadius:"0 10px 10px 0", display:"flex", alignItems:"center", gap:10, marginTop:8 }}>
              <AlertCircle size={14} color="#D97706"/>
              <span style={{ fontSize:12, color:"#92400E" }}>
                Réservation <strong>annulée automatiquement</strong> sans paiement sous <strong>1 heure</strong>.
              </span>
            </div>
          </>)}
        </div>

        {/* Contenu scrollable */}
        <div style={{ padding:26, overflowY:"auto", flex:1 }}>

          {/* Expiré */}
          {cancelled && (
            <div style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:20, paddingTop:10, textAlign:"center" }}>
              <div style={{ width:80, height:80, borderRadius:"50%", background:"linear-gradient(135deg,#FEE2E2,#FECACA)", display:"flex", alignItems:"center", justifyContent:"center", border:"4px solid #FECDD3" }}>
                <Timer size={36} color="#EF4444" strokeWidth={1.5}/>
              </div>
              <div>
                <h3 style={{ fontFamily:"'Syne',sans-serif", fontSize:22, fontWeight:800, color:"#0A1628", marginBottom:8 }}>Délai expiré</h3>
                <p style={{ fontSize:14, color:"#64748B", lineHeight:1.8, maxWidth:340 }}>
                  Réservation <strong style={{ color:"#374151" }}>#{reservation.booking_code}</strong> <strong style={{ color:"#DC2626" }}>automatiquement annulée</strong>.
                </p>
              </div>
              <div style={{ background:"#FFFBEB", border:"1px solid #FDE68A", borderRadius:14, padding:"14px 18px" }}>
                <p style={{ fontSize:13, color:"#92400E", fontWeight:600 }}>💡 Créez une nouvelle réservation depuis les excursions.</p>
              </div>
              <button onClick={onClose} style={{ padding:"13px 36px", background:"#0A1628", color:"white", border:"none", borderRadius:14, fontSize:14, fontWeight:700, cursor:"pointer", fontFamily:"inherit" }}>
                Fermer
              </button>
            </div>
          )}

          {!cancelled && (<>

          {/* STEP 1 */}
          {step === 1 && (
            <div style={{ display:"flex", flexDirection:"column", gap:20 }}>
              <div style={{ borderRadius:18, overflow:"hidden", height:190, position:"relative", background:"linear-gradient(135deg,#0e7490,#2B96A8)" }}>
                {exc?.photos?.[0] && <img src={exc.photos[0]} alt="" style={{ width:"100%", height:"100%", objectFit:"cover" }}/>}
                <div style={{ position:"absolute", inset:0, background:"linear-gradient(to top,rgba(0,0,0,.55) 0%,transparent 50%)" }}/>
                <div style={{ position:"absolute", bottom:14, left:16, right:16 }}>
                  <h3 style={{ fontFamily:"'Syne',sans-serif", fontSize:18, fontWeight:800, color:"white", marginBottom:5 }}>{exc?.title}</h3>
                  <div style={{ display:"flex", alignItems:"center", gap:5 }}>
                    <MapPin size={11} color="rgba(255,255,255,.8)"/>
                    <span style={{ fontSize:12, color:"rgba(255,255,255,.9)" }}>{exc?.city}</span>
                  </div>
                </div>
              </div>

              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8 }}>
                {[
                  { label:"Date",      value: fmtDate(reservation.date, true),     icon:"📅" },
                  { label:"Heure",     value: reservation.time,                    icon:"🕐" },
                  { label:"Voyageurs", value:`${reservation.people_count} pers.`,  icon:"👥" },
                  { label:"Durée",     value:`${exc?.duration_hours ?? "–"}h`,      icon:"⏱" },
                ].map(({ label, value, icon }) => (
                  <div key={label} style={{ background:"#F8FAFC", borderRadius:14, padding:"12px 14px", border:"1px solid #E2E8F0" }}>
                    <p style={{ fontSize:10, fontWeight:700, color:"#94A3B8", textTransform:"uppercase", letterSpacing:.6, marginBottom:5 }}>{icon} {label}</p>
                    <p style={{ fontSize:14, fontWeight:700, color:"#0A1628", margin:0 }}>{value}</p>
                  </div>
                ))}
              </div>

              <div style={{ border:"1.5px solid #E2E8F0", borderRadius:18, overflow:"hidden" }}>
                <div style={{ background:"#F8FAFC", padding:"14px 18px", borderBottom:"1px solid #E2E8F0" }}>
                  <p style={{ fontSize:11, fontWeight:700, color:"#64748B", textTransform:"uppercase", letterSpacing:1, margin:0 }}>Détail des frais</p>
                </div>
                <div style={{ padding:"16px 18px", display:"flex", flexDirection:"column", gap:10 }}>
                  <div style={{ display:"flex", justifyContent:"space-between" }}>
                    <span style={{ fontSize:14, color:"#475569" }}>{exc?.price_per_person} TND × {reservation.people_count} pers.</span>
                    <span style={{ fontSize:14, fontWeight:700, color:"#0A1628" }}>{base} TND</span>
                  </div>
                  <div style={{ display:"flex", justifyContent:"space-between" }}>
                    <span style={{ fontSize:14, color:"#475569" }}>Frais de service</span>
                    <span style={{ fontSize:14, fontWeight:700, color:"#0A1628" }}>{fee} TND</span>
                  </div>
                  <div style={{ height:1, background:"#E2E8F0" }}/>
                  <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                    <span style={{ fontFamily:"'Syne',sans-serif", fontSize:15, fontWeight:800, color:"#0A1628" }}>Total</span>
                    <span style={{ fontFamily:"'Syne',sans-serif", fontSize:22, fontWeight:800, color:"#2B96A8" }}>{total} TND</span>
                  </div>
                </div>
              </div>

              <div style={{ display:"flex", alignItems:"center", gap:8, padding:"12px 14px", background:"#F0FDF4", borderRadius:12, border:"1px solid #BBF7D0" }}>
                <ShieldCheck size={15} color="#16A34A"/>
                <span style={{ fontSize:13, color:"#15803D", fontWeight:600 }}>Annulation gratuite jusqu'à 24h avant</span>
              </div>

              <button onClick={() => setStep(2)} className="pay-btn-dark"
                style={{ width:"100%", padding:15, border:"none", borderRadius:14, fontSize:14, fontWeight:700, cursor:"pointer", fontFamily:"inherit", display:"flex", alignItems:"center", justifyContent:"center", gap:8, transition:"all .2s" }}>
                Continuer <ChevronRight size={16}/>
              </button>
            </div>
          )}

          {/* STEP 2 */}
          {step === 2 && (
            <div style={{ display:"flex", flexDirection:"column", gap:20 }}>
              <div style={{ display:"flex", gap:12, alignItems:"center", background:"#F8FAFC", border:"1px solid #E2E8F0", borderRadius:16, padding:"14px 16px" }}>
                <div style={{ width:46, height:46, borderRadius:12, overflow:"hidden", flexShrink:0, background:"#E2E8F0" }}>
                  {exc?.photos?.[0] && <img src={exc.photos[0]} alt="" style={{ width:"100%", height:"100%", objectFit:"cover" }}/>}
                </div>
                <div style={{ flex:1 }}>
                  <p style={{ fontSize:13, fontWeight:700, color:"#0A1628", margin:"0 0 3px" }}>{exc?.title}</p>
                  <p style={{ fontSize:12, color:"#64748B", margin:0 }}>{fmtDate(reservation.date)} · {reservation.people_count} pers.</p>
                </div>
                <p style={{ fontFamily:"'Syne',sans-serif", fontSize:18, fontWeight:800, color:"#0A1628", margin:0 }}>{total} <span style={{ fontSize:11, fontWeight:500, color:"#94A3B8" }}>TND</span></p>
              </div>
              <div>
                <label style={{ display:"flex", alignItems:"center", gap:7, fontSize:13, fontWeight:700, color:"#0A1628", marginBottom:10 }}>
                  <MessageSquare size={14} color="#2B96A8"/> Besoins spéciaux
                  <span style={{ fontSize:12, color:"#94A3B8", fontWeight:400 }}>— optionnel</span>
                </label>
                <textarea
                  value={specialNote} onChange={e => setSpecialNote(e.target.value)}
                  placeholder="Handicap, allergies, préférences particulières…"
                  rows={4}
                  style={{ width:"100%", padding:"13px 14px", border:"1.5px solid #E2E8F0", borderRadius:12, fontSize:14, fontFamily:"inherit", outline:"none", resize:"vertical", color:"#0A1628", background:"#FAFAFA", boxSizing:"border-box", lineHeight:1.6 }}
                  onFocus={e => (e.target.style.borderColor="#2B96A8")}
                  onBlur={e  => (e.target.style.borderColor="#E2E8F0")}
                />
              </div>
              <button onClick={() => setStep(3)} className="pay-btn-dark"
                style={{ width:"100%", padding:15, border:"none", borderRadius:14, fontSize:14, fontWeight:700, cursor:"pointer", fontFamily:"inherit", display:"flex", alignItems:"center", justifyContent:"center", gap:8 }}>
                Passer au paiement <ChevronRight size={16}/>
              </button>
            </div>
          )}

          {/* STEP 3 */}
          {step === 3 && (
            <div style={{ display:"flex", flexDirection:"column", gap:20 }}>
              <div style={{ background:"linear-gradient(135deg,#0A1628,#1E3A5F)", borderRadius:20, padding:"24px", color:"white", textAlign:"center", position:"relative", overflow:"hidden" }}>
                <div style={{ position:"absolute", top:-20, right:-20, width:120, height:120, borderRadius:"50%", background:"rgba(43,150,168,.15)", pointerEvents:"none" }}/>
                <p style={{ fontSize:12, opacity:.7, marginBottom:8, fontWeight:600, letterSpacing:.5 }}>MONTANT TOTAL À PAYER</p>
                <p style={{ fontFamily:"'Syne',sans-serif", fontSize:42, fontWeight:800, letterSpacing:"-2px", margin:"0 0 6px" }}>
                  {total} <span style={{ fontSize:20, fontWeight:600, opacity:.7 }}>TND</span>
                </p>
                <p style={{ fontSize:12, opacity:.55 }}>dont {fee} TND de frais de service</p>
              </div>

              <div>
                <p style={{ fontSize:13, fontWeight:700, color:"#0A1628", marginBottom:12 }}>Méthode de paiement</p>
                <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
                  {PAY_METHODS.map(m => (
                    <button key={m.id} className="pay-method"
                      onClick={() => { setPayMethod(m.id); setError(""); setFlouciUrl(null); }}
                      style={{ display:"flex", alignItems:"center", gap:14, padding:"14px 16px", border:`2px solid ${payMethod===m.id ? "#2B96A8" : "#E2E8F0"}`, borderRadius:14, background: payMethod===m.id ? "#EFF9FB" : "white", cursor:"pointer", textAlign:"left", transition:"all .15s", fontFamily:"inherit" }}>
                      <div style={{ width:44, height:44, borderRadius:12, background: payMethod===m.id ? "linear-gradient(135deg,#0e7490,#2B96A8)" : "#F1F5F9", display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0, transition:"background .15s" }}>
                        <m.Icon size={18} color={payMethod===m.id ? "white" : "#64748B"} strokeWidth={1.5}/>
                      </div>
                      <div style={{ flex:1 }}>
                        <p style={{ fontSize:14, fontWeight:700, color:"#0A1628", margin:"0 0 2px" }}>{m.label}</p>
                        <p style={{ fontSize:12, color:"#94A3B8", margin:0 }}>{m.sub}</p>
                      </div>
                      {m.id==="flouci" && <span style={{ fontSize:10, fontWeight:700, padding:"3px 8px", background:"#DCFCE7", color:"#15803D", borderRadius:20 }}>Recommandé</span>}
                      <div style={{ width:20, height:20, borderRadius:"50%", border:`2px solid ${payMethod===m.id ? "#2B96A8" : "#D1D5DB"}`, background:"white", display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
                        {payMethod===m.id && <div style={{ width:10, height:10, borderRadius:"50%", background:"#2B96A8" }}/>}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {error && (
                <div style={{ display:"flex", gap:8, padding:"11px 14px", background:"#FFF1F2", border:"1px solid #FECDD3", borderRadius:12 }}>
                  <AlertCircle size={15} color="#DC2626" style={{ flexShrink:0 }}/>
                  <span style={{ fontSize:13, color:"#DC2626" }}>{error}</span>
                </div>
              )}

              {flouciUrl && (
                <div style={{ padding:"16px", background:"#F0FDF4", border:"1.5px solid #86EFAC", borderRadius:16 }}>
                  <p style={{ fontSize:13, fontWeight:700, color:"#15803D", marginBottom:12, display:"flex", alignItems:"center", gap:6 }}>
                    <CheckCircle size={14}/> Lien de paiement prêt
                  </p>
                  <a href={flouciUrl} target="_blank" rel="noopener noreferrer"
                    style={{ display:"flex", alignItems:"center", justifyContent:"center", gap:8, padding:"14px", background:"#16A34A", color:"white", border:"none", borderRadius:12, fontSize:14, fontWeight:700, textDecoration:"none" }}>
                    <ExternalLink size={15}/> Payer {total} TND via Flouci
                  </a>
                </div>
              )}

              {!flouciUrl && (
                <button onClick={handlePay} disabled={loading} className="pay-btn-primary"
                  style={{ width:"100%", padding:16, border:"none", borderRadius:14, fontSize:15, fontWeight:700, cursor: loading ? "not-allowed" : "pointer", fontFamily:"inherit", display:"flex", alignItems:"center", justifyContent:"center", gap:10, opacity: loading ? .7 : 1, boxShadow:"0 6px 20px rgba(43,150,168,.4)", transition:"all .2s" }}>
                  {loading
                    ? <><Loader2 size={17} style={{ animation:"rspin 1s linear infinite" }}/> Traitement…</>
                    : payMethod==="flouci"
                      ? <><CreditCard size={17}/> Générer le lien · {total} TND</>
                      : <><CheckCircle size={17}/> Confirmer · {total} TND</>
                  }
                </button>
              )}
              <p style={{ textAlign:"center", fontSize:12, color:"#94A3B8", display:"flex", alignItems:"center", justifyContent:"center", gap:5 }}>
                <ShieldCheck size={12}/> Paiement sécurisé · VoyajAime
              </p>
            </div>
          )}

          {/* STEP 4 — Succès */}
          {step === 4 && (
            <div style={{ display:"flex", flexDirection:"column", gap:20, paddingTop:8 }}>
              <div style={{ textAlign:"center", padding:"20px 0 10px" }}>
                <div style={{ width:72, height:72, borderRadius:"50%", background:"#D1FAE5", display:"flex", alignItems:"center", justifyContent:"center", margin:"0 auto 16px", border:"4px solid #A7F3D0" }}>
                  <CheckCircle size={36} color="#10B981" strokeWidth={2}/>
                </div>
                <h3 style={{ fontFamily:"'Syne',sans-serif", fontSize:22, fontWeight:800, color:"#0A1628", marginBottom:6 }}>Paiement enregistré !</h3>
                <p style={{ fontSize:14, color:"#64748B", lineHeight:1.7 }}>Votre réservation est confirmée. 📧</p>
              </div>

              <div style={{ border:"2px solid #E2E8F0", borderRadius:20, overflow:"hidden" }}>
                <div style={{ background:"linear-gradient(135deg,#0A1628,#1E3A5F)", padding:"20px 22px" }}>
                  <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start" }}>
                    <div>
                      <p style={{ fontSize:10, color:"rgba(255,255,255,.6)", fontWeight:700, textTransform:"uppercase", letterSpacing:1, marginBottom:4 }}>Excursion</p>
                      <p style={{ fontFamily:"'Syne',sans-serif", fontSize:16, fontWeight:800, color:"white", marginBottom:4 }}>{exc?.title}</p>
                      <p style={{ fontSize:12, color:"rgba(255,255,255,.75)", display:"flex", alignItems:"center", gap:4, margin:0 }}>
                        <MapPin size={11}/> {exc?.city}
                      </p>
                    </div>
                    <div style={{ textAlign:"right" }}>
                      <p style={{ fontSize:10, color:"rgba(255,255,255,.6)", fontWeight:700, textTransform:"uppercase", letterSpacing:1, marginBottom:4 }}>Total payé</p>
                      <p style={{ fontFamily:"'Syne',sans-serif", fontSize:22, fontWeight:800, color:"white" }}>{total} TND</p>
                    </div>
                  </div>
                </div>

                <div style={{ padding:"18px 22px", display:"flex", flexDirection:"column", gap:14 }}>
                  {[
                    { Icon:Ticket,       label:"Code réservation",   value: reservation.booking_code },
                    { Icon:CalendarDays, label:"Date & heure",        value: `${fmtDate(reservation.date)} · ${reservation.time}` },
                    { Icon:Users,        label:"Voyageurs",           value: `${reservation.people_count} personne${reservation.people_count>1?"s":""}` },
                    { Icon:Navigation,   label:"Lieu de rendez-vous", value: exc?.meeting_point || exc?.city || "Communiqué par le prestataire" },
                    { Icon:Phone,        label:"Contact d'urgence",   value: "+216 70 000 000" },
                  ].map(({ Icon, label, value }) => (
                    <div key={label} style={{ display:"flex", gap:12, alignItems:"flex-start" }}>
                      <div style={{ width:36, height:36, borderRadius:10, background:"#EFF9FB", display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
                        <Icon size={15} color="#2B96A8" strokeWidth={1.5}/>
                      </div>
                      <div>
                        <p style={{ fontSize:10, color:"#94A3B8", fontWeight:700, textTransform:"uppercase", letterSpacing:.5, marginBottom:2 }}>{label}</p>
                        <p style={{ fontSize:14, fontWeight:700, color:"#0A1628", margin:0 }}>{value}</p>
                      </div>
                    </div>
                  ))}
                </div>

                <div style={{ display:"flex", alignItems:"center", padding:"0 10px", borderTop:"2px dashed #E2E8F0" }}>
                  <div style={{ width:20, height:20, borderRadius:"50%", background:"#F8FAFC", border:"2px solid #E2E8F0", flexShrink:0, marginLeft:-20 }}/>
                  <div style={{ flex:1 }}/>
                  <div style={{ width:20, height:20, borderRadius:"50%", background:"#F8FAFC", border:"2px solid #E2E8F0", flexShrink:0, marginRight:-20 }}/>
                </div>

                <div style={{ padding:"14px 22px 18px", background:"#F8FAFC", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                  <div style={{ display:"flex", alignItems:"center", gap:6 }}>
                    <div style={{ width:8, height:8, borderRadius:"50%", background:"#10B981" }}/>
                    <span style={{ fontSize:12, fontWeight:700, color:"#065F46" }}>Paiement confirmé</span>
                  </div>
                  <span style={{ fontSize:12, color:"#94A3B8", fontFamily:"monospace" }}>#{reservation.booking_code}</span>
                </div>
              </div>

              <div style={{ display:"flex", gap:10 }}>
                <button onClick={onClose} style={{ flex:1, padding:14, background:"#F1F5F9", color:"#374151", border:"none", borderRadius:14, fontSize:14, fontWeight:700, cursor:"pointer", fontFamily:"inherit" }}>
                  Fermer
                </button>
                <Link href="/touriste/historique" onClick={onClose}
                  style={{ flex:2, padding:14, background:"#0A1628", color:"white", borderRadius:14, textDecoration:"none", fontSize:14, fontWeight:700, display:"flex", alignItems:"center", justifyContent:"center", gap:8 }}>
                  <History size={15}/> Voir l'historique
                </Link>
              </div>
            </div>
          )}
          </>)}
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
//  ReservationCard — Design élégant
// ═══════════════════════════════════════════════════════════════════════
function ReservationCard({ r, onPay, onRefresh }: { r: Reservation; onPay: () => void; onRefresh?: () => void }) {
  const exc   = r.excursion;
  const s     = STATUS_CONFIG[r.status] ?? STATUS_CONFIG.pending;
  const photo = exc?.photos?.[0];
  const paid  = r.payment_status === "paid" || r.status === "confirmed" || r.status === "completed";
  const days  = daysUntil(r.date);

  const [timeLeftCard, setTimeLeftCard] = useState<number|null>(null);

  useEffect(() => {
    if (r.status !== "pending" || paid || !r.payment_deadline) return;
    const deadline = new Date(r.payment_deadline).getTime();
    const tick = () => {
      const left = Math.max(0, Math.floor((deadline - Date.now()) / 1000));
      setTimeLeftCard(left);
      if (left === 0 && onRefresh) onRefresh();
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [r.status, r.payment_deadline, paid, onRefresh]);

  const cardUrgent = timeLeftCard !== null && timeLeftCard <= 300;

  return (
    <div className="res-card">
      {/* Image */}
      <div className="res-card-img">
        {photo
          ? <img src={photo} alt={exc?.title || ""} />
          : <div style={{ width:"100%", height:"100%", display:"flex", alignItems:"center", justifyContent:"center" }}>
              <Compass size={36} color="rgba(255,255,255,.3)" strokeWidth={1}/>
            </div>
        }
        <div className="res-card-img-overlay"/>

        {/* Status badge */}
        <div className="res-status-badge" style={{ background: s.bg, border:`1px solid ${s.border}`, color: s.color }}>
          <span style={{ width:6, height:6, borderRadius:"50%", background:s.dot, flexShrink:0 }}/>
          {s.label}
        </div>

        {/* Paid badge */}
        {paid && (
          <div className="res-paid-badge">
            <CheckCircle size={10} strokeWidth={2.5}/> Payée
          </div>
        )}

        {/* Days until */}
        {days >= 0 && (
          <div className="res-days-badge">
            <CalendarDays size={11} color="#2B96A8"/>
            {days === 0 ? "Aujourd'hui !" : days === 1 ? "Demain" : `J-${days}`}
          </div>
        )}
      </div>

      {/* Body */}
      <div className="res-card-body">
        <h3 className="res-card-title">{exc?.title ?? "Excursion"}</h3>
        <p className="res-card-city">
          <MapPin size={11} color="#2B96A8" strokeWidth={2}/>
          {exc?.city}
          {exc?.rating && exc.rating > 0 && (
            <span style={{ marginLeft:8, display:"flex", alignItems:"center", gap:3 }}>
              <Star size={11} fill="#F59E0B" color="#F59E0B"/><span style={{ color:"#F59E0B", fontWeight:700 }}>{exc.rating.toFixed(1)}</span>
            </span>
          )}
        </p>

        {/* Info grid */}
        <div className="res-info-grid">
          {[
            { label:"Date",     value: fmtDate(r.date, true) },
            { label:"Heure",    value: r.time },
            { label:"Personnes",value: `${r.people_count} pers.` },
            { label:"Durée",    value: `${exc?.duration_hours ?? "–"}h` },
          ].map(({ label, value }) => (
            <div key={label} className="res-info-item">
              <p className="res-info-label">{label}</p>
              <p className="res-info-value">{value}</p>
            </div>
          ))}
        </div>

        {/* Countdown */}
        {timeLeftCard !== null && timeLeftCard > 0 && (
          <div className={`res-countdown ${cardUrgent ? "res-countdown-urgent" : "res-countdown-normal"}`}>
            <span style={{ fontSize:11, fontWeight:600, color: cardUrgent ? "#DC2626" : "#059669", display:"flex", alignItems:"center", gap:4 }}>
              <Timer size={11}/> {cardUrgent ? "⚠ Urgent !" : "Expire dans"}
            </span>
            <span style={{ fontSize:13, fontFamily:"monospace", fontWeight:800, color: cardUrgent ? "#DC2626" : "#065F46" }}>
              {Math.floor(timeLeftCard/60).toString().padStart(2,"0")}:{(timeLeftCard%60).toString().padStart(2,"0")}
            </span>
          </div>
        )}

        {timeLeftCard === 0 && (
          <div style={{ padding:"8px 12px", background:"#FFF1F2", border:"1px solid #FECDD3", borderRadius:10, marginBottom:10 }}>
            <span style={{ fontSize:11, color:"#DC2626", fontWeight:700 }}>⏱ Délai expiré — réservation annulée</span>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="res-card-footer">
        <div>
          <p className="res-price-label">Total</p>
          <p className="res-price-num">{r.total_price} <span style={{ fontSize:12, fontWeight:500, color:"#94A3B8" }}>TND</span></p>
          <span className="res-code">#{r.booking_code}</span>
        </div>

        {!paid && r.status !== "cancelled" && timeLeftCard !== 0 && (
          <button onClick={onPay} className="res-pay-btn">
            <CreditCard size={13} strokeWidth={2}/> Payer maintenant
          </button>
        )}

        {paid && (
          <Link href={`/excursions/${exc?.id}`}
            style={{ display:"inline-flex", alignItems:"center", gap:6, padding:"10px 16px", background:"#F0FDF4", color:"#065F46", border:"1px solid #A7F3D0", borderRadius:12, fontSize:12, fontWeight:700, textDecoration:"none" }}>
            <TrendingUp size={12}/> Voir détails
          </Link>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
//  Export principal
// ═══════════════════════════════════════════════════════════════════════
export default function ReservationsClient({
  reservations: init,
  autoOpenId,
}: {
  reservations: Reservation[];
  autoOpenId?: string;
}) {
  const supabase = createClient();
  const [reservations, setReservations] = useState(init);
  const [checkout,     setCheckout]     = useState<Reservation|null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const total     = reservations.length;
  const pending   = reservations.filter(r => r.status === "pending").length;
  const confirmed = reservations.filter(r => r.status === "confirmed").length;

  // ── Auto-move to history when excursion date has passed ──────────────
  const moveExpiredToHistory = useCallback(async (resas: Reservation[]) => {
    const expired = resas.filter(r => {
      const isPaid = r.payment_status === "paid" || r.status === "confirmed" || r.status === "completed";
      return isPaid && r.date < TODAY;
    });

    for (const r of expired) {
      try {
        // Insert dans historique_reservations
        const exc = r.excursion;
        await supabase.from("historique_reservations").insert({
          original_reservation_id: r.id,
          booking_code:    r.booking_code,
          excursion_id:    exc?.id    || null,
          excursion_title: exc?.title || null,
          excursion_city:  exc?.city  || null,
          date:            r.date,
          time:            r.time,
          people_count:    r.people_count,
          total_price:     r.total_price,
          platform_fee:    r.platform_fee,
          payment_method:  "confirmed",
          payment_status:  "paid",
          payment_date:    new Date().toISOString(),
          moved_to_history: true,
        });

        // Marquer comme completed dans reservations
        await supabase.from("reservations")
          .update({ status: "completed" })
          .eq("id", r.id)
          .neq("status", "completed");

      } catch (e) {
        console.warn("moveExpiredToHistory:", e);
      }
    }
  }, [supabase]);

  const refreshReservations = useCallback(async () => {
    setIsRefreshing(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const today = new Date().toISOString().split("T")[0];

      const { data, error } = await supabase
        .from("reservations")
        .select(`*, excursion:excursions(id, title, city, photos, duration_hours, price_per_person, meeting_point, rating)`)
        .eq("touriste_id", user.id)
        .neq("status", "cancelled")
        .gte("date", today)                   // ← seulement les réservations futures
        .order("date", { ascending: true });

      if (error) throw error;

      const fresh = data || [];

      // Déplacer les expirées vers historique
      await moveExpiredToHistory(fresh);

      // Re-filtrer après déplacement
      setReservations(fresh.filter(r => r.date >= today));
    } catch (err) {
      console.error("Erreur refresh:", err);
    } finally {
      setIsRefreshing(false);
    }
  }, [supabase, moveExpiredToHistory]);

  // Refresh auto toutes les 30 secondes si pending
  useEffect(() => {
    const interval = setInterval(() => {
      if (reservations.some(r => r.status === "pending")) refreshReservations();
    }, 30000);
    return () => clearInterval(interval);
  }, [reservations, refreshReservations]);

  // Refresh au montage pour déplacer les éventuelles passées
  useEffect(() => {
    moveExpiredToHistory(init);
  }, []);

  // Auto-open checkout
  useEffect(() => {
    if (autoOpenId) {
      const target = reservations.find(r => r.id === autoOpenId);
      if (target && target.payment_status !== "paid" && target.status !== "cancelled") setCheckout(target);
    } else {
      const latestUnpaid = reservations
        .filter(r => r.status === "pending" && !r.payment_status)
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())[0];
      if (latestUnpaid) setCheckout(latestUnpaid);
    }
  }, [reservations, autoOpenId]);

  function handlePaid(id: string) {
    setReservations(prev => prev.map(r => r.id === id ? { ...r, payment_status:"paid", status:"confirmed" } : r));
    setCheckout(null);
    setTimeout(() => refreshReservations(), 2000);
  }

  return (
    <div className="res-page">
      <style>{GLOBAL_CSS}</style>

      {/* Header */}
      <div className="res-header">
        <div>
          <h1 className="res-title">Mes réservations</h1>
          <p className="res-subtitle">Gérez et suivez vos aventures en Tunisie</p>
        </div>
        <button onClick={refreshReservations} disabled={isRefreshing}
          style={{ display:"flex", alignItems:"center", gap:6, padding:"10px 18px", background:"white", border:"1px solid #E2E8F0", borderRadius:40, fontSize:13, fontWeight:600, cursor:"pointer", color:"#475569", boxShadow:"0 1px 3px rgba(0,0,0,.04)", fontFamily:"inherit", transition:"all .15s" }}>
          <RefreshCcw size={13} style={isRefreshing ? { animation:"rspin 1s linear infinite" } : {}}/> Actualiser
        </button>
      </div>

      {/* Stats */}
      {total > 0 && (
        <div className="res-stats">
          {[
            { label:"réservation", count:total,     color:"#2B96A8", icon:"🗺️" },
            { label:"en attente",   count:pending,   color:"#F59E0B", icon:"⏳" },
            { label:"confirmée",    count:confirmed, color:"#10B981", icon:"✅" },
          ].map(({ label, count, color, icon }) => (
            <div key={label} className="res-stat-pill">
              <span>{icon}</span>
              <span className="num" style={{ color }}>{count}</span>
              <span>{label}{count > 1 ? "s" : ""}</span>
            </div>
          ))}
        </div>
      )}

      {/* Refreshing indicator */}
      {isRefreshing && (
        <div className="res-refreshing">
          <Loader2 size={14} style={{ animation:"rspin 1s linear infinite" }}/> Mise à jour…
        </div>
      )}

      {/* Empty state */}
      {total === 0 ? (
        <div className="res-empty">
          <div className="res-empty-icon">
            <Compass size={36} color="#2B96A8" strokeWidth={1.5}/>
          </div>
          <h3 style={{ fontFamily:"'Syne',sans-serif", fontSize:22, fontWeight:800, color:"#0A1628", marginBottom:8 }}>Aucune réservation active</h3>
          <p style={{ fontSize:14, color:"#64748B", marginBottom:28, lineHeight:1.6 }}>
            Découvrez les excursions et planifiez votre prochain voyage en Tunisie
          </p>
          <Link href="/excursions" style={{ display:"inline-flex", alignItems:"center", gap:8, padding:"14px 28px", background:"linear-gradient(135deg,#0e7490,#2B96A8)", color:"white", borderRadius:14, textDecoration:"none", fontSize:14, fontWeight:700, boxShadow:"0 6px 20px rgba(43,150,168,.35)" }}>
            <Sparkles size={16}/> Explorer les excursions <ArrowRight size={15}/>
          </Link>
          <Link href="/touriste/historique" style={{ display:"inline-flex", alignItems:"center", gap:8, padding:"14px 28px", background:"#F1F5F9", color:"#475569", borderRadius:14, textDecoration:"none", fontSize:14, fontWeight:700, marginLeft:12 }}>
            <History size={15}/> Voir l'historique
          </Link>
        </div>
      ) : (
        <div className="res-grid">
          {reservations.map((r, i) => (
            <div key={r.id} style={{ animationDelay:`${i * .07}s` }}>
              <ReservationCard r={r} onPay={() => setCheckout(r)} onRefresh={refreshReservations}/>
            </div>
          ))}
        </div>
      )}

      {checkout && (
        <CheckoutModal
          reservation={checkout}
          onClose={() => setCheckout(null)}
          onPaid={handlePaid}
          autoStart={!!autoOpenId && checkout.id === autoOpenId}
        />
      )}
    </div>
  );
}