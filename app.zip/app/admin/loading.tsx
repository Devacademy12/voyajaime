export { default } from "../loading";
