import React from 'react';
import { Search } from 'lucide-react';

interface DataListProps<T> {
  items: T[];
  isEmpty: boolean;
  emptyMessage: string;
  renderItem: (item: T) => React.ReactNode;
  className?: string;
  gap?: number;
}

export function DataList<T>({
  items,
  isEmpty,
  emptyMessage,
  renderItem,
  className = '',
  gap = 10,
}: DataListProps<T>) {
  if (isEmpty) {
    return (
      <div
        style={{
          textAlign: 'center',
          padding: '60px 20px',
          background: 'white',
          borderRadius: 16,
          border: '1px solid #F3F4F6',
        }}
      >
        <div
          style={{
            width: 56,
            height: 56,
            borderRadius: '50%',
            background: '#F3F4F6',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            margin: '0 auto 14px',
          }}
        >
          <Search size={26} color="#9CA3AF" strokeWidth={1.5} />
        </div>
        <p
          style={{
            fontWeight: 700,
            color: '#111827',
            fontSize: 15,
            margin: 0,
          }}
        >
          {emptyMessage}
        </p>
      </div>
    );
  }

  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        gap,
      }}
      className={className}
    >
      {items.map(renderItem)}
    </div>
  );
}
