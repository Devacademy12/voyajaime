// ─────────────────────────────────────────────
//  components/ui/StatusBadge.tsx
// ─────────────────────────────────────────────
import { StatusConfig } from "../../../lib/statusConfig";

interface Props {
  status: string;
  config: Record<string, StatusConfig>;
  size?: "sm" | "md";
  showIcon?: boolean;
}

export default function StatusBadge({ status, config, size = "md", showIcon = false }: Props) {
  const cfg = config[status] ?? {
    label: status,
    color: "#6B7280",
    bg: "#F9FAFB",
    border: "#E5E7EB",
    dot: "#6B7280",
  };

  const pad = size === "sm" ? "3px 9px" : "5px 12px";
  const fs  = size === "sm" ? 11 : 12;

  return (
    <span style={{
      padding: pad,
      borderRadius: 20,
      background: cfg.bg,
      color: cfg.color,
      fontSize: fs,
      fontWeight: 700,
      display: "inline-flex",
      alignItems: "center",
      gap: 5,
      whiteSpace: "nowrap",
    }}>
      <span style={{
        width: 6, height: 6, borderRadius: "50%",
        background: cfg.dot, display: "inline-block",
      }} />
      {showIcon && cfg.icon && <cfg.icon size={fs - 2} />}
      {cfg.label}
    </span>
  );
}