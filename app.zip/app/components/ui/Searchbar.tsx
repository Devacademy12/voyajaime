// ─────────────────────────────────────────────
//  components/ui/SearchBar.tsx
// ─────────────────────────────────────────────
"use client";
import { Search } from "lucide-react";

interface Props {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  className?: string;
}

export default function SearchBar({ value, onChange, placeholder = "Rechercher...", className }: Props) {
  return (
    <div style={{ position: "relative", flex: 1, minWidth: 200 }} className={className}>
      <Search
        size={15}
        color="#9CA3AF"
        style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", pointerEvents: "none" }}
      />
      <input
        type="text"
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
        style={{
          width: "100%",
          padding: "10px 14px 10px 38px",
          border: "1.5px solid #DCE5FF",
          borderRadius: 12,
          fontSize: 13,
          fontFamily: "inherit",
          outline: "none",
          color: "#053366",
          background: "white",
          transition: "border .2s",
        }}
        onFocus={e => {
          e.target.style.borderColor = "#02AFCF";
          e.target.style.boxShadow = "0 0 0 3px rgba(2,175,207,.1)";
        }}
        onBlur={e => {
          e.target.style.borderColor = "#DCE5FF";
          e.target.style.boxShadow = "none";
        }}
      />
    </div>
  );
}