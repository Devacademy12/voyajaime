// ─────────────────────────────────────────────
//  components/ui/StatCard.tsx
// ─────────────────────────────────────────────
import type { ReactNode } from "react";

interface Props {
  label: string;
  value: string | number;
  suffix?: string;
  icon: ReactNode;
  color: string;
  bg: string;
  border: string;
  delay?: number;
}

export default function StatCard({ label, value, suffix, icon, color, bg, border, delay = 0 }: Props) {
  return (
    <div style={{
      background: "white",
      border: `1px solid ${border}`,
      borderRadius: 16,
      padding: "18px 20px",
      display: "flex",
      alignItems: "center",
      gap: 14,
      boxShadow: "0 2px 10px rgba(5,51,102,.05)",
      animationDelay: `${delay}s`,
      cursor: "default",
      transition: "all .2s",
    }}
    className="stat-card"
    >
      <div style={{
        width: 44, height: 44, borderRadius: 12,
        background: bg, border: `1px solid ${border}`,
        display: "flex", alignItems: "center", justifyContent: "center",
        color, flexShrink: 0,
      }}>
        {icon}
      </div>
      <div>
        <p style={{
          fontSize: 12, color: "#9CA3AF", fontWeight: 500,
          margin: "0 0 4px", textTransform: "uppercase", letterSpacing: "0.4px",
        }}>
          {label}
        </p>
        <p style={{ fontSize: 22, fontWeight: 900, color: "#053366", margin: 0, lineHeight: 1 }}>
          {value}
          {suffix && <span style={{ fontSize: 13, fontWeight: 500, color: "#9CA3AF", marginLeft: 4 }}>{suffix}</span>}
        </p>
      </div>
    </div>
  );
}