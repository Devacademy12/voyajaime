import React from 'react';
import { ToastState } from '../../lib/useToast';

interface ToastProps {
  toast: ToastState | null;
}

export const Toast: React.FC<ToastProps> = ({ toast }) => {
  if (!toast) return null;

  return (
    <div
      className={`fixed top-4 right-4 z-50 px-4 py-2 rounded-md shadow-lg transition-all duration-300 ${
        toast.ok
          ? 'bg-green-500 text-white border border-green-600'
          : 'bg-red-500 text-white border border-red-600'
      }`}
    >
      {toast.msg}
    </div>
  );
};