import React from 'react';
import { StatusConfig } from '../../../lib/statusConfig';

interface FilterTab {
  key: string;
  label: string;
  icon?: React.ElementType;
  count?: number;
}

interface Props {
  tabs: FilterTab[];
  activeTab: string;
  onTabChange: (key: string) => void;
  className?: string;
}

export function FilterTabs({ tabs, activeTab, onTabChange, className = "" }: Props) {
  return (
    <div style={{ display: "flex", gap: 8, marginBottom: 24 }} className={className}>
      {tabs.map(({ key, label, icon: Icon, count }) => (
        <button
          key={key}
          className={`filter-tab ${activeTab === key ? "active" : ""}`}
          onClick={() => onTabChange(key)}
          style={{
            padding: "8px 16px",
            borderRadius: 20,
            border: "1px solid #E5E7EB",
            cursor: "pointer",
            fontSize: 13,
            fontWeight: 600,
            fontFamily: "inherit",
            transition: "all .2s",
            display: "inline-flex",
            alignItems: "center",
            gap: 6,
            background: activeTab === key ? "#2B96A8" : "white",
            color: activeTab === key ? "white" : "#6B7280",
          }}
          onMouseEnter={(e) => {
            if (activeTab !== key) {
              e.currentTarget.style.background = "#F9FAFB";
            }
          }}
          onMouseLeave={(e) => {
            if (activeTab !== key) {
              e.currentTarget.style.background = "white";
            }
          }}
        >
          {Icon && <Icon size={13} strokeWidth={2} />}
          {label}
          {count !== undefined && (
            <span
              style={{
                fontSize: 11,
                borderRadius: 12,
                padding: "1px 7px",
                fontWeight: 800,
                background: activeTab === key ? "rgba(255,255,255,.25)" : "#F3F4F6",
                color: activeTab === key ? "white" : "#6B7280",
              }}
            >
              {count}
            </span>
          )}
        </button>
      ))}
    </div>
  );
}