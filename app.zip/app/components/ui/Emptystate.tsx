// ─────────────────────────────────────────────
//  components/ui/EmptyState.tsx
// ─────────────────────────────────────────────
import type { ReactNode } from "react";

interface Props {
  icon: ReactNode;
  title: string;
  subtitle?: string;
  action?: ReactNode;
}

export default function EmptyState({ icon, title, subtitle, action }: Props) {
  return (
    <div style={{
      textAlign: "center",
      padding: "60px 20px",
      background: "white",
      borderRadius: 20,
      border: "1px solid #EEF2FF",
    }}>
      <div style={{
        width: 64, height: 64, borderRadius: "50%",
        background: "rgba(2,175,207,.08)",
        display: "flex", alignItems: "center", justifyContent: "center",
        margin: "0 auto 16px",
      }}>
        {icon}
      </div>
      <p style={{ fontSize: 15, fontWeight: 700, color: "#053366", marginBottom: 6 }}>{title}</p>
      {subtitle && <p style={{ fontSize: 13, color: "#9CA3AF", marginBottom: action ? 16 : 0 }}>{subtitle}</p>}
      {action}
    </div>
  );
}